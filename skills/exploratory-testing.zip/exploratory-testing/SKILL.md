---
name: exploratory-testing
description: Run structured exploratory testing of web apps — unscripted, charter-guided discovery that finds defects scripted tests miss, including accessibility and usability/UX issues. Use this skill whenever the user wants to explore an app for bugs without pre-written cases, or wants to assess accessibility or UX. Trigger when the user mentions exploratory testing, session-based testing, test charters, testing tours, heuristic evaluation, "find bugs without a script", "poke around this app", "what's broken here"; or accessibility, a11y, WCAG, keyboard navigation, screen reader, color contrast, focus order; or usability, UX testing, "is this intuitive", "test the user experience", "does this match our design". Drives exploration through Playwright and feeds findings back into scripted suites.
---

# Exploratory Testing

Simultaneous learning, test design, and execution — guided by a charter, not a script.
Where black-box runs cases you designed in advance, exploratory discovers what you didn't
know to ask. You navigate, observe, form a hypothesis from something surprising, follow it,
and document what you find. Accessibility and usability are two lenses you explore through.

This is structured, not random. Charters, tours, heuristics, and oracles keep it
systematic and repeatable. The output isn't just bugs — it's new questions and new
scripted-test candidates.

## Workflow

### 1. Set the charter

A charter is a one-line mission that bounds the session. ALWAYS frame it as:

> Explore **(target)** using **(resources/tours)** to discover **(what information)**.

Example: "Explore checkout with invalid coupons and edge quantities to discover how errors
and totals behave." Time-box it (e.g. 30–60 min of activity). One charter per session — if
you find a second thread worth pulling, note it as a *new charter*, don't derail.

### 2. Understand the target and locate oracles

- Establish the entry point, roles, and test data (as in any web testing).
- **Find the oracles** — how you'll recognize a bug. For usability, look for a `DESIGN.md`
  (or design system / style guide) in the repo and load it; it's the source of truth for
  UI/UX expectations. See `references/usability.md`. For accessibility, the oracle is WCAG
  — see `references/accessibility.md`. For function, it's consistency heuristics (HICCUPPS)
  in `references/charters-and-tours.md`.

### 3. Choose the lens(es)

| Charter is about...                                     | Lens / reference                   |
|---------------------------------------------------------|------------------------------------|
| General behavior, edge cases, "what breaks"             | Functional — charters-and-tours.md |
| Can everyone use it (keyboard, screen reader, contrast) | Accessibility — accessibility.md   |
| Is it clear, consistent, on-design, pleasant to use     | Usability — usability.md           |

Most sessions pick one lens. A broad "explore this page" session can rotate through all
three as separate passes — don't blend them in one pass or findings get muddy.

### 4. Explore

Drive the app through Playwright (see the black-box skill's playwright patterns for
selectors / auth / evidence if installed). Within the charter:

- Run **tours** — structured ways to traverse the app (money tour, landmark tour,
  back-alley tour). See charters-and-tours.md.
- Apply **heuristics** — SFDPOT for coverage, Goldilocks (too big / too small / just right)
  for inputs, CRUD for data.
- **Follow surprises.** The core loop: observe something unexpected → hypothesize why →
  probe to confirm → capture. A surprising result is the whole point; chase it.
- Vary inputs, sequences, timing, and navigation (back / refresh / concurrent tabs) — the
  combinations a scripted suite never tried.

### 5. Capture as you go

Don't rely on memory — log during the session, not after. ALWAYS record per session:

- **Charter** and time spent.
- **Observations** — what you tried and saw (the trail, not just conclusions).
- **Bugs** — each with steps to reproduce, expected vs actual, evidence (screenshot/trace).
- **Questions** — things you couldn't resolve / need a human or spec to judge.
- **New charters** — threads worth a future session.

### 6. Debrief and report

ALWAYS report in this structure:

```
# Exploratory Session Report
## Charter
(the mission + time spent + lens)
## Coverage
(areas/tours actually exercised — and what you deliberately didn't reach)
## Bugs found
(per bug: severity, steps to reproduce, expected vs actual, evidence path)
## Observations & questions
(notable behavior, things needing human/spec judgment)
## New test-case candidates
(scripted cases this session suggests adding to the black-box suite)
## New charters
(threads for future sessions)
```

Feed the candidates back into scripted testing — converting a discovery into a repeatable
case is how exploratory pays off long-term.

## Principles

- **Charter-guided, not random.** A mission and a time box make exploration accountable.
- **Observation over assertion.** You're discovering behavior, not confirming a known answer.
- **Follow the surprise.** The unexpected response is the lead — pursue it.
- **Document the journey.** A bug nobody can reproduce is noise; capture the trail.
- **Feed the scripted suite.** Each discovery should leave behind a reusable case.
- **The human curates.** Surface candidates and judgment calls; don't assert taste as fact.
