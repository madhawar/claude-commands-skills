---
name: test-cases-from-code
description: >-
  Build, update, and gap-fill software test cases by reverse-engineering behavior
  directly from a feature-branch codebase, for situations where domain knowledge,
  domain experts, and existing automated tests are all scarce or absent. Use this
  whenever the user needs to test features they don't fully understand, has test
  cases (often in Excel) that may be outdated, wants to generate test scenarios from
  source code, needs to reconcile existing test cases against what the code actually
  does, or is QA-ing a feature branch whose author is unreachable. Trigger on phrasing
  like "create test cases from this branch", "our test cases are outdated", "fill the
  gaps in our test scenarios", "test this feature without domain knowledge", "no one
  knows how this works", or any case where the codebase must serve as the spec and the
  oracle. Works best with direct feature-branch access (e.g. Claude Code).
---

# Test Cases From Code

Recover a usable, honest test suite for a feature when the codebase is the only
reliable source of truth — no current spec, no reachable author, no domain expert,
no existing automated tests.

## The spine — read this before doing anything

Three principles govern every phase. They are not optional flavor; they are what
separates this from "an LLM guessed some test cases."

**1. The codebase is the oracle, but it only proves behavior-as-written — never
correctness.** A bug that is faithfully implemented in code looks identical to
correct behavior when code is your only reference. You can verify that a feature is
internally consistent and self-coherent. You cannot verify that it is *right*. Say
so plainly in every handoff. The difference between "I tested this" and "I confirmed
it behaves as written" is the whole point.

**2. Three questions, three different resolutions. Keep them separate.**
- *"What does it do?"* -> answerable from code. This is most of the work.
- *"Does the existing test match what it does?"* -> answerable by diffing. Mechanical.
- *"Is what it does correct / what it should do?"* -> **NOT answerable from code.**
  Requires intent authority. When that's absent, you escalate the question — you do
  not answer it yourself.

**3. Never confabulate intent.** Inferring *why* the code does something and
presenting that inference as "the requirement" is the single most dangerous failure
mode in this work, because it launders an assumption into a baseline that everyone
downstream then trusts. When the code's intent is ambiguous, write "intent unclear"
and route it to a human. This rule binds you and any model or tool you delegate to.

Because of principle 1, **every output item carries a provenance label** so readers
always know what was verified versus assumed. The taxonomy is below.

## Provenance labels (for test cases)

| Label | Meaning |
|---|---|
| `CODE-VERIFIED` | Expected result derived from code **and** confirmed by running the app. |
| `CODE-DERIVED` | Derived from code, not yet executed against a running system. |
| `EXISTING-OK` | Pre-existing test case; matches current code; retained as-is. |
| `EXISTING-UPDATED` | Pre-existing test case was stale; rewritten to match current code. |
| `DISCREPANCY` | Existing expectation conflicts with code; the correct result is *contested*. Linked to a risk-register entry. **Do not mark pass/fail** until adjudicated. |

## Risk-register entry types

| Type | Meaning |
|---|---|
| `DISCREPANCY-INTENT-UNKNOWN` | Excel and code disagree, and no authority exists to say which is right. Either a real bug or a stale test — undeterminable from code alone. |
| `LIKELY-BUG-INCONSISTENCY` | An internal contradiction or smell (see consistency catalog) that is suspicious *regardless of domain knowledge*. |
| `NEEDS-STAKEHOLDER-DECISION` | A genuine "what should it do" question that code cannot answer. |

## Workflow

Work the phases in order. Skip a phase only when its inputs don't exist (e.g. no
existing Excel -> skip reconciliation), and say so explicitly. Detailed procedures
for each pass live in `references/analysis-passes.md` — read it when you reach that
phase. The smell catalog for Phase 3 lives in `references/consistency-smells.md`.

### Phase 0 — Triage and hunt for intent authority
Before extracting anything, establish two things.

First, which scenario you're in: **greenfield** (no existing tests), **gap-fill**
(some tests, want coverage), or **update** (tests exist but are probably stale).

Second — and this changes everything downstream — **how resolvable contradictions
will be.** Hunt for any weaker substitute for the unreachable author, in this order
of value: the PR/MR description, commit messages on the branch, whoever reviewed or
approved it and is still around, linked tickets/issues, user-facing help or training
docs. A single PR description stating what the feature was *supposed* to do can
collapse a large chunk of the eventual "intent unknown" register into "intent stated
here." Spend ten minutes here before committing to the fully expert-less path.

Output: a short note — scenario type, what intent sources exist (if any), and who
holds release authority for this feature (the person discrepancies will route to).

### Phase 1 — Extract the behavioral spec from the branch
Produce a **behavioral spec**, not a code summary: a flat, numbered list of testable
statements of the form "when X, the system does Y," each with a `file:line` citation.
Mine the locations where rules concentrate — schema and DB constraints, validation
logic, conditional branches, state/workflow transitions, calculations, authorization
gates, and especially error/warning messages paired with their trigger conditions
(usually the clearest plain-language statement of business logic in the system).
Apply principle 3: report only what the code does; never the inferred intent.

Output: the cited behavioral spec.

### Phase 2 — Reconcile against existing test scenarios *(skip if greenfield)*
Diff the behavioral spec against the existing Excel into three buckets: **matches
code** (retain -> `EXISTING-OK`), **contradicts code** (-> `DISCREPANCY` + register
entry `DISCREPANCY-INTENT-UNKNOWN`), and **code rule with no test** (-> coverage gap,
feeds Phase 4). The contradictions are the highest-value output of the whole skill,
*and* the ones you cannot resolve alone — that's why they go to the register, not to
a verdict. (Use the xlsx skill to read the Excel.)

Output: reconciliation table + the list of coverage gaps.

### Phase 3 — Consistency hunt
The only correctness proxies you have without domain knowledge are the code's
contradictions with *itself*. Scan the branch for the smells in
`references/consistency-smells.md` — dead branches, contradictory validations,
states with no exit, reachable divide-by-zero/overflow, overlapping error triggers,
boundary/off-by-one mismatches, and so on. Each finding gets a `file:line` and a
severity, and lands in the register as `LIKELY-BUG-INCONSISTENCY`. A self-contradiction
is one of the few things that's a likely bug even when you don't know the intended
behavior.

Output: smell findings with severity.

### Phase 4 — Generate / update test cases
Turn the coverage gaps (Phase 2) and the smells (Phase 3) into concrete test cases
using the schema below. Rewrite stale existing cases to match code (`EXISTING-UPDATED`).
Weight new cases toward **boundaries and error paths** — the happy path is the part
most likely to be both already covered and already correct; the edges are where stale
specs and unverified code both hide problems. Every expected result must cite the
`file:line` that justifies it. New cases start as `CODE-DERIVED` until Phase 5.

Output: the test-case set (schema below).

### Phase 5 — Exploratory execution against the app
Run the cases against the deployed feature branch, using the app itself as the oracle
and the behavioral spec as your charter list. This is where you catch cases where the
running system and the code disagree (config, environment, data state). Cases that
pass against the app get promoted `CODE-DERIVED -> CODE-VERIFIED`. **Do not execute
`DISCREPANCY` cases to a verdict** — their correct result is still contested.

Output: executed test cases with status; any new app-vs-code findings -> register.

### Phase 6 — Risk register and handoff
Assemble everything unresolved into a single register routed to the release owner,
each entry carrying its type, the code behavior (`file:line`), the old expectation
(if any), why it's unresolved, and a **blank decision field** for someone with
authority to ratify. Close with the honest coverage statement (see template).

Output: risk register + coverage statement.

## Output schemas

**Test case** (columns map directly to a spreadsheet):

| Column | Notes |
|---|---|
| ID | Stable identifier. |
| Feature / area | What it exercises. |
| Precondition / data state | What must be true first. |
| Steps | Action + concrete input. |
| Expected result | The observable outcome. |
| Source | `file:line` that justifies the expected result. **Required.** |
| Provenance | One of the provenance labels above. |
| Status | Pass / Fail / Blocked / Not run. (Blank for `DISCREPANCY` until adjudicated.) |
| Linked risk | Risk-register ID, if any. |

**Risk register:**

| Column | Notes |
|---|---|
| ID | Stable identifier. |
| Type | One of the register entry types above. |
| Description | Plain-language summary. |
| Code behavior | `file:line`. |
| Old / expected behavior | From Excel, if applicable. |
| Why unresolved | E.g. "author unreachable; should-question; no spec." |
| Routed to | The release owner / PM. |
| Decision | **Left blank** until ratified by authority. |

**Coverage statement** — always include, verbatim in spirit:
> Verified: the feature behaves as written in the code on branch `<name>`, and is
> internally consistent except where noted in the risk register. **Not verified:**
> that this behavior is correct or matches intended requirements — no current spec,
> author, or domain expert was available to confirm intent. `<N>` discrepancies and
> `<M>` likely-bug inconsistencies require a decision from the release owner before
> this feature can be called validated.

## Output format
Default to the structured tables above as markdown for the user to review. Produce a
spreadsheet (via the xlsx skill) only when the user wants to merge results back into
their Excel workflow or hand them to someone else.
