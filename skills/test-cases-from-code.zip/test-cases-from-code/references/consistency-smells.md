# Consistency Smells

Code patterns that are suspicious **regardless of domain knowledge**, because the code
contradicts itself or is provably unsafe. Use in Phase 3. For each finding, record
`file:line`, a one-line description, and severity.

| Smell | What it looks like | Why suspicious without domain knowledge | Confirm by |
|---|---|---|---|
| Dead / unreachable branch | A condition that can never be true given upstream constraints or earlier guards. | Either the guard is wrong or the branch is vestigial; both are defects. | Trace the values that reach the condition. |
| Contradictory validations | Two rules that can't both hold, or one forbids what another requires. | No input can satisfy the feature; guaranteed broken path. | Find an input and check both rules against it. |
| State with no exit / orphan state | A workflow state with no outgoing transition, or a transition to a state that doesn't exist. | Users get stuck, or a path is unreachable. | Map the transition graph. |
| Reachable divide-by-zero / overflow | A divisor or accumulator that a reachable input can drive to 0 or past range. | Crash or silently wrong number on real input. | Trace the operand's possible range. |
| Overlapping / shadowed errors | Two error conditions match the same input; the first always wins, the second is dead. | One error message can never fire; logic intent is unclear. | Check condition order and overlap. |
| Boundary / off-by-one mismatch | `>` where comparable code uses `>=`, inclusive vs exclusive used inconsistently for the same quantity. | The edge case behaves differently in two places; at least one is wrong. | Compare the boundary handling across sites. |
| Inconsistent rounding / precision | The same quantity computed with different rounding or decimal precision in different places. | Totals won't reconcile; a real correctness bug. | Compare the calculation sites. |
| Default contradicts validation | A default value that the validator for the same field would reject. | The default state is invalid; intent is incoherent. | Run the default through the validator logic. |
| Swallowed exception on a live path | `catch` that discards the error on a path where the outcome matters. | Failures vanish silently; wrong result with no signal. | Check whether the path produces user-visible output. |
| Missing enum case | An enum/constant handled in some switches but not all. | An unhandled value falls through to wrong/default behavior. | Diff handled cases against the enum definition. |
| Inconsistent authz across paths | An action gated on one entry point but reachable ungated via another. | Privilege check is bypassable; security-relevant. | Find all call paths to the protected action. |
| TOCTOU / check-then-use gap | A value checked, then used after something could have changed it. | Check and use can diverge; intermittent wrong behavior. | Inspect what can mutate the value between check and use. |
