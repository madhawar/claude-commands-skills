# Analysis Passes

Detailed procedure for each phase of `test-cases-from-code`. Read the relevant
section when you reach that phase. These describe analysis you (the agent with repo
access) perform directly against the checked-out branch.

## Universal guardrail — paste into your own reasoning for every pass
> Report only what the code does, with a `file:line` for each claim. Do **not** infer
> or state the intended, expected, or "correct" behavior. Where the code's purpose is
> ambiguous, write "intent unclear" rather than guessing. Distinguishing "what it does"
> from "what it should do" is the core discipline; the second is never answered here.

## Pass A — Behavioral spec extraction (Phase 1)
Walk the branch's diff against its base to scope what the feature touches, then read
the touched modules. Extract testable statements from these high-density locations,
roughly in this priority:

1. **Schema & DB constraints** — enums, nullability, uniqueness, foreign keys,
   defaults, check constraints. Each encodes a domain rule directly.
2. **Validation logic** — field and cross-field rules; what's rejected and the message.
3. **Conditional branches** — every `if`/`switch` and the condition that selects each
   path. Each branch is at least one test case.
4. **State / workflow transitions** — allowed transitions, guards, terminal states.
5. **Calculations** — formulas, rounding, units, precedence; trace inputs to outputs.
6. **Authorization gates** — who can do what, on which paths.
7. **Error/warning messages + triggers** — pair each message with the exact condition
   that raises it. Usually the clearest plain-language business logic in the codebase.

Emit each as: `[id] When <condition>, system <does Y>. (path/file.ext:line)`. Keep
statements atomic — one rule each — so each maps cleanly to a test case later.

## Pass B — Reconciliation (Phase 2)
Load the existing Excel (xlsx skill). For each existing test case, find the spec
statement(s) it corresponds to and classify:
- **Match** -> retain, label `EXISTING-OK`.
- **Contradiction** -> the Excel's expected result conflicts with the code's actual
  behavior. Label the case `DISCREPANCY`; open a register entry
  `DISCREPANCY-INTENT-UNKNOWN` recording both behaviors and their citations. Do not
  attempt to decide which is right.
- **No corresponding code rule** -> the test references behavior the branch doesn't
  implement (possibly removed, possibly never built). Flag for the register.

Then invert: every spec statement with **no** existing test -> coverage gap (feeds
Pass D). Produce a coverage table: rules total, covered, gap, contradicted.

## Pass C — Consistency hunt (Phase 3)
Scan for the smells in `consistency-smells.md`. For each, give `file:line`, a one-line
description, and severity (high = reachable crash / silent wrong result; medium =
contradictory or dead logic; low = stylistic risk). File each as
`LIKELY-BUG-INCONSISTENCY`. These need no domain knowledge to flag because the code
disagrees with itself — that's the signal.

## Pass D — Test generation (Phase 4)
For each coverage gap and each high/medium smell, write a test case in the schema.
Rules:
- Concrete inputs and observable expected results — no "verify it works correctly."
- Cite the `file:line` that justifies the expected result in the Source column.
- Cover both sides of every boolean branch and each enum/state value.
- For boundaries, test the value, value +/- 1, and the inclusive/exclusive edge.
- For each error condition, one case that triggers it and one that just misses.
- New cases = `CODE-DERIVED`. Rewritten stale cases = `EXISTING-UPDATED`.
- For a smell, write the case that would expose it, label `DISCREPANCY`, link the
  register entry, and leave Status blank — its "correct" result is contested.

## Pass E — Execution notes (Phase 5)
Execute against the running branch. Record actual result, Pass/Fail/Blocked, and any
environment/data preconditions discovered. Promote passing `CODE-DERIVED -> CODE-VERIFIED`.
On a code-vs-running-app divergence, open a register entry and cite both. Never drive
a `DISCREPANCY` case to a verdict.
